USE online_exam;

-- Demo passwords:
-- admin@example.com    / admin123
-- student1@example.com / student123
-- student2@example.com / student123
-- student3@example.com / student123
INSERT INTO USERS(email,full_name,password_hash,role) VALUES
('student1@example.com','Arun Kumar','703b0a3d6ad75b649a28adde7d83c6251da457549263bc7ff45ec709b0a8448b','STUDENT'),
('student2@example.com','Priya Sharma','703b0a3d6ad75b649a28adde7d83c6251da457549263bc7ff45ec709b0a8448b','STUDENT'),
('student3@example.com','Karthik Raj','703b0a3d6ad75b649a28adde7d83c6251da457549263bc7ff45ec709b0a8448b','STUDENT'),
('admin@example.com','Exam Administrator','240be518fabd2724ddb6f04eeb1da5967448d7e831c08c8fa822809f74c720a9','ADMIN');

INSERT INTO EXAMS(title,description,duration_minutes) VALUES
('Java Fundamentals','Core Java, OOP, collections and exceptions.',30),
('SQL & Database Basics','SQL queries, joins, keys, normalization and transactions.',30),
('Web Development Basics','HTML, CSS, JavaScript and REST fundamentals.',20);

INSERT INTO QUESTIONS(exam_id,question_text,option_a,option_b,option_c,option_d,correct_option) VALUES
(1,'Which keyword is used to inherit a class in Java?','implements','extends','inherits','super','B'),
(1,'Which collection does not allow duplicate elements?','List','ArrayList','Set','Queue','C'),
(1,'What is the default value of a boolean field?','true','false','null','0','B'),
(1,'Which exception is unchecked?','IOException','SQLException','ClassNotFoundException','NullPointerException','D'),
(1,'Which principle hides internal implementation details?','Encapsulation','Inheritance','Polymorphism','Overloading','A'),
(2,'Which SQL command retrieves rows?','SELECT','INSERT','UPDATE','DELETE','A'),
(2,'Which key uniquely identifies a row?','Foreign key','Primary key','Candidate text','Index only','B'),
(2,'Which JOIN returns matching rows from both tables?','LEFT JOIN','RIGHT JOIN','INNER JOIN','FULL JOIN','C'),
(2,'Which clause filters grouped results?','WHERE','ORDER BY','GROUP BY','HAVING','D'),
(2,'Which command permanently saves a transaction?','SAVE','COMMIT','PUSH','APPLY','B'),
(3,'Which HTML element creates a hyperlink?','<link>','<a>','<href>','<url>','B'),
(3,'Which CSS property changes text color?','font-style','background','color','text-size','C'),
(3,'Which JavaScript keyword declares a block-scoped variable?','var','let','define','value','B'),
(3,'What does REST commonly use to exchange data?','JSON','BMP','EXE','ZIP','A'),
(3,'Which HTTP method is normally used to create a resource?','GET','DELETE','POST','HEAD','C');
