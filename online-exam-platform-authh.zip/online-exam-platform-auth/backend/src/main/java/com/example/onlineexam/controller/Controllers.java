package com.example.onlineexam.controller;

import com.example.onlineexam.dto.ApiDtos.*;
import com.example.onlineexam.service.Services;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Map;

@RestController
@CrossOrigin(origins="*")
@RequestMapping("/api")
public class Controllers {
 private final Services s;
 public Controllers(Services s){this.s=s;}

 @PostMapping("/auth/register") public UserDto register(@Valid @RequestBody RegisterRequest x){return s.register(x);}
 @PostMapping("/auth/login") public AuthResponse login(@Valid @RequestBody LoginRequest x){return new AuthResponse(s.login(x));}
 @GetMapping("/users") public List<UserDto> users(){return s.users();}
 @GetMapping("/users/{id}") public UserDto user(@PathVariable long id){return s.user(id);}
 @PostMapping("/users") public UserDto createUser(@Valid @RequestBody UserRequest x){return s.createUser(x);}

 @GetMapping("/exams") public List<ExamDto> exams(){return s.exams();}
 @GetMapping("/exams/{id}") public ExamDto exam(@PathVariable long id){return s.exam(id);}
 @PostMapping("/exams") public ExamDto createExam(@Valid @RequestBody ExamRequest x){return s.createExam(x);}
 @PutMapping("/exams/{id}") public ExamDto updateExam(@PathVariable long id,@Valid @RequestBody ExamRequest x){return s.updateExam(id,x);}
 @DeleteMapping("/exams/{id}") public Map<String,String> deleteExam(@PathVariable long id){s.deleteExam(id);return Map.of("message","deleted");}
 @GetMapping("/exams/{id}/questions") public List<QuestionDto> questions(@PathVariable long id){return s.questions(id);}
 @PostMapping("/exams/{id}/questions") public QuestionDto addQuestion(@PathVariable long id,@Valid @RequestBody QuestionRequest x){return s.addQuestion(id,x);}
 @PutMapping("/questions/{id}") public QuestionDto updateQuestion(@PathVariable long id,@Valid @RequestBody QuestionRequest x){return s.updateQuestion(id,x);}
 @DeleteMapping("/questions/{id}") public Map<String,String> deleteQuestion(@PathVariable long id){s.deleteQuestion(id);return Map.of("message","deleted");}

 @GetMapping("/attempts") public List<AttemptDto> attempts(){return s.attempts();}
 @GetMapping("/attempts/user/{id}") public List<AttemptDto> userAttempts(@PathVariable long id){return s.userAttempts(id);}
 @PostMapping("/attempts/start") public AttemptDto start(@RequestBody StartAttemptRequest x){return s.start(x);}
 @PutMapping("/attempts/{a}/answers/{q}") public Map<String,String> answer(@PathVariable long a,@PathVariable long q,@Valid @RequestBody AnswerRequest x){s.answer(a,q,x);return Map.of("message","saved");}
 @PostMapping("/attempts/{id}/submit") public ResultDto submit(@PathVariable long id){return s.submit(id);}
 @GetMapping("/attempts/above-average/{id}") public List<AboveAverageDto> aboveAverage(@PathVariable long id){return s.aboveAverage(id);}
}
