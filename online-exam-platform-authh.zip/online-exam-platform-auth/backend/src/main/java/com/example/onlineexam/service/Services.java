package com.example.onlineexam.service;

import com.example.onlineexam.dto.ApiDtos.*;
import com.example.onlineexam.repository.DatabaseRepository;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class Services {
 public final DatabaseRepository db;
 public Services(DatabaseRepository db){this.db=db;}
 public List<UserDto> users(){return db.users();}
 public UserDto createUser(UserRequest x){return db.createUser(x);}
 public UserDto register(RegisterRequest x){return db.register(x);}
 public UserDto login(LoginRequest x){return db.login(x);}
 public UserDto user(long id){return db.user(id);}
 public List<ExamDto> exams(){return db.exams();}
 public ExamDto exam(long id){return db.exam(id);}
 public ExamDto createExam(ExamRequest x){return db.createExam(x);}
 public ExamDto updateExam(long id,ExamRequest x){return db.updateExam(id,x);}
 public void deleteExam(long id){db.deleteExam(id);}
 public List<QuestionDto> questions(long id){return db.questions(id);}
 public QuestionDto addQuestion(long id,QuestionRequest x){return db.addQuestion(id,x);}
 public QuestionDto updateQuestion(long id,QuestionRequest x){return db.updateQuestion(id,x);}
 public void deleteQuestion(long id){db.deleteQuestion(id);}
 public AttemptDto start(StartAttemptRequest x){return db.start(x);}
 public void answer(long a,long q,AnswerRequest x){db.answer(a,q,x.selectedOption());}
 public ResultDto submit(long id){return db.submit(id);}
 public List<AttemptDto> attempts(){return db.attempts();}
 public List<AttemptDto> userAttempts(long id){return db.userAttempts(id);}
 public List<AboveAverageDto> aboveAverage(long id){return db.aboveAverage(id);}
}
