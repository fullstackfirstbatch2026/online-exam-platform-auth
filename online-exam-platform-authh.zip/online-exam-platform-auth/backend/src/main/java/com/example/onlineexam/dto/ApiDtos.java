package com.example.onlineexam.dto;

import jakarta.validation.constraints.*;

public final class ApiDtos {
 private ApiDtos(){}
 public record UserDto(Long id,String email,String fullName,String role,String createdAt){}
 public record UserRequest(@NotBlank @Email String email,@NotBlank String fullName,@NotBlank String role){}
 public record RegisterRequest(@NotBlank @Email String email,@NotBlank @Size(min=6,max=100) String password,@NotBlank @Size(min=2,max=120) String fullName){}
 public record LoginRequest(@NotBlank @Email String email,@NotBlank String password){}
 public record AuthResponse(UserDto user){}
 public record ExamDto(Long id,String title,String description,int durationMinutes,String createdAt,int questionCount){}
 public record ExamRequest(@NotBlank String title,String description,@Min(1) @Max(480) int durationMinutes){}
 public record QuestionDto(Long id,Long examId,String questionText,String optionA,String optionB,String optionC,String optionD){}
 public record QuestionRequest(@NotBlank String questionText,@NotBlank String optionA,@NotBlank String optionB,@NotBlank String optionC,@NotBlank String optionD,@Pattern(regexp="[ABCD]") String correctOption){}
 public record StartAttemptRequest(Long userId,Long examId){}
 public record AnswerRequest(@Pattern(regexp="[ABCD]") String selectedOption){}
 public record AttemptDto(Long id,Long userId,String userName,String userEmail,Long examId,String examTitle,int score,String status,String startedAt,String submittedAt){}
 public record ResultDto(Long attemptId,String status,int score,int totalQuestions,double percentage,String submittedAt){}
 public record AboveAverageDto(Long userId,String studentName,String email,Long examId,String examTitle,int score,double averageScore){}
}
