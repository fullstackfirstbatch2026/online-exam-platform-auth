package com.example.onlineexam.repository;

import com.example.onlineexam.dto.ApiDtos.*;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.HexFormat;
import java.util.List;
import java.util.Map;

@Repository
public class DatabaseRepository {
 private final JdbcTemplate db;
 public DatabaseRepository(JdbcTemplate db){this.db=db;}

 public List<UserDto> users(){return db.query("SELECT id,email,full_name,role,created_at FROM USERS ORDER BY full_name",
  (r,n)->mapUser(r));}

 public UserDto createUser(UserRequest x){
  db.update("INSERT INTO USERS(email,full_name,password_hash,role) VALUES(?,?,?,?)",x.email(),x.fullName(),hash(x.email()),x.role());
  return userByEmail(x.email());
 }

 public UserDto register(RegisterRequest x){
  if(existsEmail(x.email())) throw new IllegalArgumentException("Email is already registered");
  db.update("INSERT INTO USERS(email,full_name,password_hash,role) VALUES(?,?,?,'STUDENT')",x.email().trim().toLowerCase(),x.fullName().trim(),hash(x.password()));
  return userByEmail(x.email());
 }

 public UserDto login(LoginRequest x){
  List<UserDto> found=db.query("SELECT id,email,full_name,role,created_at FROM USERS WHERE email=? AND password_hash=?",
   (r,n)->mapUser(r),x.email().trim().toLowerCase(),hash(x.password()));
  if(found.isEmpty()) throw new IllegalArgumentException("Invalid email or password");
  return found.get(0);
 }

 public UserDto user(long id){return db.queryForObject("SELECT id,email,full_name,role,created_at FROM USERS WHERE id=?",(r,n)->mapUser(r),id);}

 public List<ExamDto> exams(){return db.query("""
  SELECT e.id,e.title,e.description,e.duration_minutes,e.created_at,COUNT(q.id) question_count
  FROM EXAMS e LEFT JOIN QUESTIONS q ON q.exam_id=e.id GROUP BY e.id ORDER BY e.id DESC
  """,(r,n)->new ExamDto(r.getLong("id"),r.getString("title"),r.getString("description"),r.getInt("duration_minutes"),ts(r.getTimestamp("created_at")),r.getInt("question_count")));}

 public ExamDto exam(long id){return db.queryForObject("""
  SELECT e.id,e.title,e.description,e.duration_minutes,e.created_at,
  (SELECT COUNT(*) FROM QUESTIONS q WHERE q.exam_id=e.id) question_count
  FROM EXAMS e WHERE e.id=?
  """,(r,n)->new ExamDto(r.getLong("id"),r.getString("title"),r.getString("description"),r.getInt("duration_minutes"),ts(r.getTimestamp("created_at")),r.getInt("question_count")),id);}

 public ExamDto createExam(ExamRequest x){db.update("INSERT INTO EXAMS(title,description,duration_minutes) VALUES(?,?,?)",x.title(),x.description(),x.durationMinutes());return exam(lastId());}
 public ExamDto updateExam(long id,ExamRequest x){db.update("UPDATE EXAMS SET title=?,description=?,duration_minutes=? WHERE id=?",x.title(),x.description(),x.durationMinutes(),id);return exam(id);}
 public void deleteExam(long id){db.update("DELETE FROM EXAMS WHERE id=?",id);}

 public List<QuestionDto> questions(long examId){return db.query("""
  SELECT id,exam_id,question_text,option_a,option_b,option_c,option_d FROM QUESTIONS WHERE exam_id=? ORDER BY id
  """,(r,n)->new QuestionDto(r.getLong("id"),r.getLong("exam_id"),r.getString("question_text"),r.getString("option_a"),r.getString("option_b"),r.getString("option_c"),r.getString("option_d")),examId);}

 public QuestionDto question(long id){return db.queryForObject("SELECT id,exam_id,question_text,option_a,option_b,option_c,option_d FROM QUESTIONS WHERE id=?",
  (r,n)->new QuestionDto(r.getLong("id"),r.getLong("exam_id"),r.getString("question_text"),r.getString("option_a"),r.getString("option_b"),r.getString("option_c"),r.getString("option_d")),id);}

 public QuestionDto addQuestion(long examId,QuestionRequest x){db.update("INSERT INTO QUESTIONS(exam_id,question_text,option_a,option_b,option_c,option_d,correct_option) VALUES(?,?,?,?,?,?,?)",examId,x.questionText(),x.optionA(),x.optionB(),x.optionC(),x.optionD(),x.correctOption());return question(lastId());}
 public QuestionDto updateQuestion(long id,QuestionRequest x){db.update("UPDATE QUESTIONS SET question_text=?,option_a=?,option_b=?,option_c=?,option_d=?,correct_option=? WHERE id=?",x.questionText(),x.optionA(),x.optionB(),x.optionC(),x.optionD(),x.correctOption(),id);return question(id);}
 public void deleteQuestion(long id){db.update("DELETE FROM QUESTIONS WHERE id=?",id);}

 public AttemptDto start(StartAttemptRequest x){
  if(!"STUDENT".equals(userRole(x.userId()))) throw new IllegalArgumentException("Only student accounts can start exams");
  List<AttemptDto> active=db.query("""
   SELECT a.id,u.id user_id,u.full_name,u.email,e.id exam_id,e.title exam_title,a.score,a.status,a.started_at,a.submitted_at
   FROM ATTEMPTS a JOIN USERS u ON u.id=a.user_id JOIN EXAMS e ON e.id=a.exam_id
   WHERE a.user_id=? AND a.exam_id=? AND a.status='IN_PROGRESS' ORDER BY a.started_at DESC LIMIT 1
   """,(rs,rowNum)->mapAttempt(rs),x.userId(),x.examId());
  if(!active.isEmpty())return active.get(0);
  db.update("INSERT INTO ATTEMPTS(user_id,exam_id) VALUES(?,?)",x.userId(),x.examId());return attempt(lastId());
 }

 public void answer(long attemptId,long questionId,String selected){
  String correct=db.queryForObject("SELECT correct_option FROM QUESTIONS WHERE id=?",String.class,questionId);
  boolean ok=selected.equals(correct);
  db.update("""
   INSERT INTO ANSWERS(attempt_id,question_id,selected_option,is_correct)
   VALUES(?,?,?,?) ON DUPLICATE KEY UPDATE selected_option=VALUES(selected_option),is_correct=VALUES(is_correct),answered_at=CURRENT_TIMESTAMP
   """,attemptId,questionId,selected,ok);
 }

 public ResultDto submit(long id){
  new SimpleJdbcCall(db).withProcedureName("submit_exam").execute(Map.of("p_attempt_id",id));
  return db.queryForObject("""
   SELECT a.id,a.status,a.score,(SELECT COUNT(*) FROM QUESTIONS q WHERE q.exam_id=a.exam_id) total_questions,a.submitted_at
   FROM ATTEMPTS a WHERE a.id=?
   """,(r,n)->{int total=r.getInt("total_questions"),score=r.getInt("score");return new ResultDto(r.getLong("id"),r.getString("status"),score,total,total==0?0:score*100.0/total,ts(r.getTimestamp("submitted_at")));},id);
 }

 public List<AttemptDto> attempts(){return db.query("""
  SELECT a.id,u.id user_id,u.full_name,u.email,e.id exam_id,e.title exam_title,a.score,a.status,a.started_at,a.submitted_at
  FROM ATTEMPTS a JOIN USERS u ON u.id=a.user_id JOIN EXAMS e ON e.id=a.exam_id ORDER BY a.started_at DESC
  """,(rs,rowNum)->mapAttempt(rs));}

 public List<AttemptDto> userAttempts(long userId){return db.query("""
  SELECT a.id,u.id user_id,u.full_name,u.email,e.id exam_id,e.title exam_title,a.score,a.status,a.started_at,a.submitted_at
  FROM ATTEMPTS a JOIN USERS u ON u.id=a.user_id JOIN EXAMS e ON e.id=a.exam_id WHERE u.id=? ORDER BY a.started_at DESC
  """,(rs,rowNum)->mapAttempt(rs),userId);}

 public AttemptDto attempt(long id){return db.queryForObject("""
  SELECT a.id,u.id user_id,u.full_name,u.email,e.id exam_id,e.title exam_title,a.score,a.status,a.started_at,a.submitted_at
  FROM ATTEMPTS a JOIN USERS u ON u.id=a.user_id JOIN EXAMS e ON e.id=a.exam_id WHERE a.id=?
  """,(rs,rowNum)->mapAttempt(rs),id);}

 public List<AboveAverageDto> aboveAverage(long examId){return db.query("""
  SELECT u.id user_id,u.full_name,u.email,a.exam_id,e.title exam_title,a.score,
  (SELECT AVG(a2.score) FROM ATTEMPTS a2 WHERE a2.exam_id=a.exam_id AND a2.status IN('PASS','FAIL')) average_score
  FROM ATTEMPTS a JOIN USERS u ON u.id=a.user_id JOIN EXAMS e ON e.id=a.exam_id
  WHERE a.exam_id=? AND a.status IN('PASS','FAIL')
  AND a.score>(SELECT AVG(a3.score) FROM ATTEMPTS a3 WHERE a3.exam_id=a.exam_id AND a3.status IN('PASS','FAIL'))
  ORDER BY a.score DESC
  """,(r,n)->new AboveAverageDto(r.getLong("user_id"),r.getString("full_name"),r.getString("email"),r.getLong("exam_id"),r.getString("exam_title"),r.getInt("score"),r.getDouble("average_score")),examId);}

 private boolean existsEmail(String email){Integer n=db.queryForObject("SELECT COUNT(*) FROM USERS WHERE email=?",Integer.class,email.trim().toLowerCase());return n!=null&&n>0;}
 private String userRole(long id){return db.queryForObject("SELECT role FROM USERS WHERE id=?",String.class,id);}
 private UserDto userByEmail(String email){return db.queryForObject("SELECT id,email,full_name,role,created_at FROM USERS WHERE email=?",(r,n)->mapUser(r),email.trim().toLowerCase());}
 private UserDto mapUser(ResultSet r)throws SQLException{return new UserDto(r.getLong("id"),r.getString("email"),r.getString("full_name"),r.getString("role"),ts(r.getTimestamp("created_at")));}
 private AttemptDto mapAttempt(ResultSet r)throws SQLException{return new AttemptDto(r.getLong("id"),r.getLong("user_id"),r.getString("full_name"),r.getString("email"),r.getLong("exam_id"),r.getString("exam_title"),r.getInt("score"),r.getString("status"),ts(r.getTimestamp("started_at")),ts(r.getTimestamp("submitted_at")));}
 private Long lastId(){return db.queryForObject("SELECT LAST_INSERT_ID()",Long.class);}
 private static String ts(Timestamp x){return x==null?null:x.toInstant().toString();}
 private static String hash(String value){try{return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(value.getBytes(StandardCharsets.UTF_8)));}catch(NoSuchAlgorithmException e){throw new IllegalStateException(e);}}
}
