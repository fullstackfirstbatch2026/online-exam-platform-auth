# Online Exam Platform — Student Registration + Staff Console

React + Vite frontend, Spring Boot backend, MySQL 8.4, Docker Compose.

## Accounts

Student registration is available from the login screen. New accounts are created with the STUDENT role.

Demo student:
- student1@example.com / student123

Demo staff:
- admin@example.com / admin123

Staff and students have separate portals. Staff can manage exams/questions and monitor students, attempts and results. Students can register, log in, take exams and see their own results.

## Run

From the project root:

```powershell
docker compose down -v
docker compose up --build
```

Open http://localhost:3000

`down -v` is required once after installing this authentication version because the MySQL schema now includes `password_hash`. It recreates the database from the SQL initialization scripts.

## Docker networking

MySQL is intentionally not exposed on a Windows host port. Backend connects to `mysql:3306` inside the Docker network. Frontend is on port 3000 and backend on 8080.

## Authentication note

This demo uses SHA-256 password hashes in the database to keep the project dependency-light. For a production deployment, use Spring Security with BCrypt/Argon2, HTTPS, server-side sessions or JWTs, authorization checks on every protected endpoint, and proper secret management.
